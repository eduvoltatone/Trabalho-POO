import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class Teste {

    @Test
    public void testAplicacaoInvestimento() {
        Cliente cliente = new Cliente("João Silva", "123456789");
        Aplicacao aplicacao = new Aplicacao(1000.0, 5.0, cliente);
        double valorInvestimento = 500.0;
        aplicacao.investir(valorInvestimento);
        assertEquals(1500.0, aplicacao.getSaldo(), 0.001); // Esperado: 1000 + 500 * (5.0 / 12)
    }

    @Test
    public void testContaCorrenteSaque() {
        Cliente cliente = new Cliente("Maria Santos", "987654321");
        Conta_Corrente contaCorrente = new Conta_Corrente(101, cliente);
        contaCorrente.depositar(1000.0);
        assertTrue(contaCorrente.sacar(500.0));
        assertEquals(500.0, contaCorrente.getSaldo(), 0.001);
    }

    @Test
    public void testContaPoupancaTransferencia() {
        Cliente cliente1 = new Cliente("Alice Johnson", "111111111");
        Cliente cliente2 = new Cliente("Bob Smith", "222222222");
        Conta_Poupanca contaPoupanca1 = new Conta_Poupanca(202, cliente1);
        Conta_Poupanca contaPoupanca2 = new Conta_Poupanca(203, cliente2);
        contaPoupanca1.depositar(1000.0);
        assertTrue(contaPoupanca1.transferir(contaPoupanca2, 300.0));
        assertEquals(700.0, contaPoupanca1.getSaldo(), 0.001);
        assertEquals(300.0, contaPoupanca2.getSaldo(), 0.001);
    }
}
