public class Main {
    public static void main(String[] args) {


        Cliente cliente1 = new Cliente("João Silva", "123456789");
        Cliente cliente2 = new Cliente("Maria Santos", "987654321");

        Conta_Corrente contaCorrenteJoao = new Conta_Corrente(101, cliente1);
        Conta_Poupanca contaPoupancaMaria = new Conta_Poupanca(202, cliente2);
        Conta_Salario contaSalarioJoao = new Conta_Salario(303, cliente1);

        contaCorrenteJoao.depositar(1000.0);
        contaPoupancaMaria.depositar(500.0);
        contaSalarioJoao.depositarSalario(2000.0);

        contaCorrenteJoao.sacar(500.0);
        contaPoupancaMaria.sacar(100.0);

        contaCorrenteJoao.transferir(contaPoupancaMaria, 300.0);

        System.out.println("Informações da Conta Corrente de João:");
        System.out.println("Número da Conta: " + contaCorrenteJoao.getNumeroConta());
        System.out.println("Saldo: R$" + contaCorrenteJoao.getSaldo());
        System.out.println("Proprietário: " + contaCorrenteJoao.getProprietario().getNome());
        System.out.println();

        System.out.println("Informações da Conta Poupança de Maria:");
        System.out.println("Número da Conta: " + contaPoupancaMaria.getNumeroConta());
        System.out.println("Saldo: R$" + contaPoupancaMaria.getSaldo());
        System.out.println("Proprietário: " + contaPoupancaMaria.getProprietario().getNome());
        System.out.println();

        System.out.println("Informações da Conta Salário de João:");
        System.out.println("Número da Conta: " + contaSalarioJoao.getNumeroConta());
        System.out.println("Saldo: R$" + contaSalarioJoao.getSaldo());
        System.out.println("Proprietário: " + contaSalarioJoao.getProprietario().getNome());


    }
}
