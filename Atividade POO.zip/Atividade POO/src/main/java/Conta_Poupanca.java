public class Conta_Poupanca extends Conta_Bancaria {
    public Conta_Poupanca(int numeroConta, Cliente proprietario) {
        super(numeroConta, 50.0, proprietario); // Saldo inicial mínimo de R$50,00
    }
}