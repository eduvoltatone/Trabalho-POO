public class Conta_Corrente extends Conta_Bancaria {
    public Conta_Corrente(int numeroConta, Cliente proprietario) {
        super(numeroConta, 0.0, proprietario); // Não requer saldo inicial
    }

}
