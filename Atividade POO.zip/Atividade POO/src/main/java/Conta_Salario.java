public class Conta_Salario extends Conta_Bancaria {
    public Conta_Salario(int numeroConta, Cliente proprietario) {
        super(numeroConta, 0.0, proprietario); // Não requer saldo inicial
    }

    public void depositarSalario(double valor) {
        depositar(valor);
    }
}
