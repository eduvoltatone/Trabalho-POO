public class Aplicacao {
    private double saldo;
    private double taxaDeJurosAnual;
    private Cliente cliente;

    public Aplicacao(double saldoInicial, double taxaDeJurosAnual, Cliente cliente) {
        this.saldo = saldoInicial;
        this.taxaDeJurosAnual = taxaDeJurosAnual;
        this.cliente = cliente;
    }

    public void investir(double valor) {
        if (valor > 0) {
            saldo += valor;
        }
    }

    public void resgatar(double valor) {
        if (valor > 0 && valor <= saldo) {
            saldo -= valor;
        }
    }

    public void calcularRendimentoMensal() {
        double rendimentoMensal = (saldo * (taxaDeJurosAnual / 12)) / 100.0;
        saldo += rendimentoMensal;
    }

    public double getSaldo() {
        return saldo;
    }
}
