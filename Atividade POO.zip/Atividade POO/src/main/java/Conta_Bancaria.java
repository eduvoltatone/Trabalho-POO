public class Conta_Bancaria {


    private int numeroConta;
    private double saldo;
    private Cliente proprietario;

    public Conta_Bancaria(int numeroConta, double saldoInicial, Cliente proprietario) {
        this.numeroConta = numeroConta;
        this.saldo = saldoInicial;
        this.proprietario = proprietario;

    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public double getSaldo() {
        return saldo;
    }

    public Cliente getProprietario() {
        return proprietario;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setProprietario(Cliente proprietario) {
        this.proprietario = proprietario;
    }

    public void depositar(double valor) {
        saldo += valor;
    }

    public boolean sacar(double valor) {
        if (saldo >= valor) {
            saldo -= valor;
            return true;
        } else {
            System.out.println("Você não tem saldo sulficiente!");
            return false;
        }
    }

    public boolean transferir(Conta_Bancaria contaDestino, double valor) {
        if (saldo >= valor && valor > 0) {
            saldo -= valor;
            contaDestino.depositar(valor);
            return true;
        } else {
            System.out.println("Transferência não realizada!");
            return false;
        }
    }
}
